const express = require('express')
const app = express()
const tiktok = require('./routes/tiktok')

app.get('/api/tiktok', tiktok)

app.listen(3000, () => {
  console.log('Server API aktif di http://localhost:3000')
})