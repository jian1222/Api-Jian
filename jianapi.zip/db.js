module.exports = {
  users: [
    {
      apikey: "jianreset123",
      owner: "62895350626000",
      premium: true,
      limit: 100,
      today_hit: 0,
      last_reset: "2025-08-04"
    }
  ]
}