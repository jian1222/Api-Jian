const axios = require('axios')
const moment = require('moment')
const db = require('../db')

module.exports = async function(req, res) {
  const { url, apikey } = req.query
  if (!apikey) return res.json({ status: false, msg: 'API key wajib diisi' })
  if (!url) return res.json({ status: false, msg: 'URL TikTok wajib diisi' })

  const user = db.users.find(u => u.apikey === apikey)
  if (!user) return res.json({ status: false, msg: 'API key tidak valid' })

  const today = moment().format('YYYY-MM-DD')
  if (user.last_reset !== today) {
    user.today_hit = 0
    user.last_reset = today
  }

  if (user.today_hit >= user.limit) {
    return res.json({ status: false, msg: 'Limit harian habis!' })
  }

  user.today_hit++

  try {
    const get = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`)
    if (!get.data || !get.data.result) throw new Error("Gagal ambil data")

    return res.json({
      status: true,
      creator: '@jianbotz',
      result: get.data.result
    })

  } catch (err) {
    return res.json({ status: false, msg: 'Gagal mengambil data TikTok', error: err.message })
  }
}